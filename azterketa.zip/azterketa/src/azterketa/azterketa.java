package azterketa;

import java.util.Scanner;

public class azterketa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int zenbakia = 1;
		int kontagailua = 0;
		int bataz_beste = 0;
		
		while (zenbakia != 0) {
			System.out.println("Sartu zenbaki bat:");
			zenbakia = sc.nextInt();
			if (zenbakia != 0) {
				bataz_beste = bataz_beste + zenbakia;
				kontagailua++;
			}
		}
		int emaitza = bataz_beste / kontagailua;
		
		System.out.println("Sartu dituzun zenbakien bataz bestekoa: " + emaitza);
		sc.close();
	}

}
